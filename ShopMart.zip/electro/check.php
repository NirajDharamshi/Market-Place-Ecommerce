<?php
 
   session_start();
   
// Accessing session data
echo 'Hi, ' . $_SESSION["user"];
?>