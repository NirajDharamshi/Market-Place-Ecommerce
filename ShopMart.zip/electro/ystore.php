 <?php
           include 'db.php';

           $result = $conn->query("SELECT *  FROM yudhajith",MYSQLI_USE_RESULT);
           /*$row = $result->fetch_assoc();*/
             ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		 <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

		<title>Shopmart</title>

 		<!-- Google font -->
 		<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

 		<!-- Bootstrap -->
 		<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css"/>

 		<!-- Slick -->
 		<link type="text/css" rel="stylesheet" href="css/slick.css"/>
 		<link type="text/css" rel="stylesheet" href="css/slick-theme.css"/>

 		<!-- nouislider -->
 		<link type="text/css" rel="stylesheet" href="css/nouislider.min.css"/>

 		<!-- Font Awesome Icon -->
 		<link rel="stylesheet" href="css/font-awesome.min.css">

 		<!-- Custom stlylesheet -->
 		<link type="text/css" rel="stylesheet" href="css/style.css"/>

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

    </head>
	<body>
		<!-- HEADER -->
		<header>
			<!-- TOP HEADER -->
			<div id="top-header">
				<div class="container">
					<ul class="header-links pull-left">
						<li><a href="tel:6462672314"><i class="fa fa-phone"></i>+6462672314</a></li>
						<li><a href="mailto:nirajdharamshi@gmail.com"><i class="fa fa-envelope-o"></i> nirajdharamshi@gmail.com</a></li>
						
					</ul>
					<ul class="header-links pull-right">
						<?php session_start();
						        if(!isset($_SESSION["user"])):?>
						 <li><a href="login.php"><i class="fa fa-user-o"></i> My Account</a></li>
                         <?php 
						        else:?>
						 <li><a><i class="fa fa-user-o"></i> <?php
						 echo 'Hi,' . $_SESSION["user"];
                              ?></a></li>  
                              <li><a href="logout.php"><i class="fa fa-user-o"></i> LogOut</a></li>
                              <?php endif; ?>   
						<li><a href="user.php"><i class="fa fa-user-o"></i> New Users</a></li>
                          
					</ul>
				</div>
			</div>
			<!-- /TOP HEADER -->

			<!-- MAIN HEADER -->
			<div id="header">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<!-- LOGO -->
						<div class="col-md-3">
							<div class="header-logo">
								<a href="index.php" class="logo">
									<img src=".\img\logo.png" alt="">
								</a>
							</div>
						</div>
						<!-- /LOGO -->

						<!-- SEARCH BAR -->
						<div class="col-md-6">
							<div class="header-search">
								<form>
									<select class="input-select">
										<option value="0">All Categories</option>
										<option value="1">Cakes</option>
										<option value="1">Software</option>
										<option value="1">Tutorials</option>
										<option value="1">Ice Cream</option>
									</select>
									<input class="input" placeholder="Search here">
									<button class="search-btn">Search</button>
								</form>
							</div>
						</div>
						<!-- /SEARCH BAR -->

						<!-- ACCOUNT -->
						<div class="col-md-3 clearfix">
							<div class="header-ctn">
								<!-- Wishlist -->
								<div>
									<a href="track.php">
										<i class="fa fa-heart-o"></i>
										<span>Visited Products</span>
										
									</a>
								</div>
								<!-- /Wishlist -->

								<!-- Cart -->
								

								<!-- Menu Toogle -->
								<div class="menu-toggle">
									<a href="#">
										<i class="fa fa-bars"></i>
										<span>Menu</span>
									</a>
								</div>
								<!-- /Menu Toogle -->
							</div>
						</div>
						<!-- /ACCOUNT -->
					</div>
					<!-- row -->
				</div>
				<!-- container -->
			</div>
			<!-- /MAIN HEADER -->
		</header>
		<!-- NAVIGATION -->
		<nav id="navigation">
			<!-- container -->
			<div class="container">
				<!-- responsive-nav -->
				<div id="responsive-nav">
					<!-- NAV -->
					<ul class="main-nav nav navbar-nav">
					<li class="active"><a href="#">Home</a></li>
						
						<li><a href="dstore.php">Cakes</a></li>
						<li><a href="kstore.php">Ice Cream</a></li>
						<li><a href="store.php">Software</a></li>
						<li><a href="ystore.php">Tutorials</a></li>
					</ul>
					<!-- /NAV -->
				</div>
				<!-- /responsive-nav -->
			</div>
			<!-- /container -->
		</nav>
		<!-- /NAVIGATION -->

			

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				
				<div >
                   <iframe width="560" height="315" src="https://www.youtube.com/embed/JrB4dU48VTM" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen style="display:block; margin: 0 auto;"></iframe>
						</div>

					

					
								
					
					

					<!-- STORE -->
					<div id="store" class="col-md-12">
						<!-- store top filter -->

						<div class="store-filter clearfix">
							<div class="store-sort">
							
							</div>
							
						</div>
						<!-- /store top filter -->
						
						<!-- store products -->
						<div class="row">
							<!-- product -->

							    <?php
               while ($row = $result->fetch_assoc()) {?>
							<div class="col-md-4 col-xs-6">
								<div class="product">
									<div class="product-img">
										<img src="<?php echo ($row['link']); ?>" alt="" width="800" height="200">
										<div class="product-label">
											
											<span class="new">NEW</span>
										</div>
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="<?php echo 'product.php?id='.($row['id']); ?>"><?php echo ($row['name']); ?></a></h3>
										<h4 class="product-price"><?php echo ($row['price']); ?><del class="product-old-price"><?php echo "  ";
										echo ((1.2)*($row['price'])); ?></del></h4>
										<div class="product-rating">
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
										</div>
										<div class="product-btns">
											<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span class="tooltipp">add to wishlist</span></button>
											
										</div>
									</div>
									
								</div>

							</div>

							<!-- /product -->

						

							<div class="clearfix visible-sm visible-xs"></div>


                            <?php  } ?>

							

						
						</div>

						<!-- /store products -->

						
					</div>
					<!-- /STORE -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- NEWSLETTER -->
		<div id="newsletter" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
						<div class="newsletter">
							<p>Sign Up for the <strong>NEWSLETTER</strong></p>
							<form>
								<input class="input" type="email" placeholder="Enter Your Email">
								<button class="newsletter-btn"><i class="fa fa-envelope"></i> Subscribe</button>
							</form>
							<ul class="newsletter-follow">
								<li>
									<a href="https://www.facebook.com/shopmart.shopmart.524"><i class="fa fa-facebook"></i></a>
								</li>
								<li>
									<a href="https://twitter.com/shopmart90"><i class="fa fa-twitter"></i></a>
								</li>
								<li>
									<a href="https://www.instagram.com/ourshopmart/"><i class="fa fa-instagram"></i></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /NEWSLETTER -->

		<!-- FOOTER -->
		<footer id="footer">
			<!-- top footer -->
			<div class="section">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">About Us</h3>
								<p>Hey this is where you do crazy shopping!</p>
								<ul class="footer-links">
									<li><i class="fa fa-map-marker"></i>33rd South 3rd Street</li>
									<li><a href="#"><i class="fa fa-phone"></i>+021-95-51-84</a></li>
									<li><a href="#"><i class="fa fa-envelope-o"></i>yudhajith@gmail.com</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Categories</h3>
								<ul class="footer-links">
									
									<li><a href="dstore.php">Cakes</a></li>
									<li><a href="kstore.php">Ice Cream</a></li>
									<li><a href="store.php">Software Services</a></li>
									<li><a href="ystore.php">Tutorials</a></li>
								</ul>
							</div>
						</div>

						<div class="clearfix visible-xs"></div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Information</h3>
								<ul class="footer-links">
									<li>About Us</li>
									<li><a href="http://elliex.ellipsis.tech">Niraj's Web</a></li>
									<li><a href="http://www.yudhajithb.com">Yudhajith's Web</a></li>
									<li><a href="http://www.kailashr.com">Kailash's Web</a></li>
									<li><a href="http://www.dhruthikuram.com">Dhruthi's Web</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Service</h3>
								<ul class="footer-links">
									<li><a href="login.php">Login</a></li>
									<li><a href="track.php">Last Visted</a></li>
									
									
								</ul>
							</div>
						</div>
					</div>
					<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /top footer -->

			<!-- bottom footer -->
			<div id="bottom-footer" class="section">
				<div class="container">
					<!-- row -->
					<div class="row">
						<div class="col-md-12 text-center">
						
							<span class="copyright">
								<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
								Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This website is made with <i class="fa fa-heart-o" aria-hidden="true"></i>
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
							</span>
						</div>
					</div>
						<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /bottom footer -->
		</footer>
		<!-- /FOOTER -->

		<!-- jQuery Plugins -->
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/slick.min.js"></script>
		<script src="js/nouislider.min.js"></script>
		<script src="js/jquery.zoom.min.js"></script>
		<script src="js/main.js"></script>

	</body>
</html>
