<?php
include 'db.php';
session_start();
                                         		$a=mysqli_real_escape_string($conn, $_REQUEST['review']);
                                         		$id=$_SESSION["product_id"];
                                         		$rating=4;
                                         		if(!isset($_SESSION["user"]))
                                         		{
                                         			 echo"<script type='text/javascript'>alert('Please login');</script>";
                                         			 echo '<script type="text/javascript">
           window.location = "login.php"
      </script>';
                                         		}
                                         		else
                                         		{
                                         		$name=$_SESSION["user"];
                                         		$sql = "INSERT INTO review (review,user_name,product_id,rating) VALUES ('$a','$name','$id',4)";
                                         	  
                                         	  if ($conn->query($sql) === TRUE) {
	echo"<script type='text/javascript'>alert('Review Submitted!');</script>";
	
    echo '<script type="text/javascript">
           window.location = "index.php"
      </script>';


} else {


   
   	echo"<script type='text/javascript'>alert('Please try again');</script>";
   	echo '<script type="text/javascript">
           window.location.reload();
      </script>';
   
}



                                         	}
                      




										?>