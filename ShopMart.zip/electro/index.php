 <?php
           include 'db.php';

        


 ?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		 <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

		<title>Shopmart</title>

		<!-- Google font -->
		<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

		<!-- Bootstrap -->
		<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css"/>

		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js">        </script>
     <script src="typeahead.min.js"></script>

	

		<!-- Slick -->
		<link type="text/css" rel="stylesheet" href="css/slick.css"/>
		<link type="text/css" rel="stylesheet" href="css/slick-theme.css"/>

		<!-- nouislider -->
		<link type="text/css" rel="stylesheet" href="css/nouislider.min.css"/>

		<!-- Font Awesome Icon -->
		<link rel="stylesheet" href="css/font-awesome.min.css">

		<!-- Custom stlylesheet -->
		<link type="text/css" rel="stylesheet" href="css/style.css"/>

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

    </head>
	<body>
		<!-- HEADER -->
		<header>
			<!-- TOP HEADER -->
			<div id="top-header">
				<div class="container">
					<ul class="header-links pull-left">
						<li><a href="tel:6462672314"><i class="fa fa-phone"></i>+6462672314</a></li>
						<li><a href="mailto:nirajdharamshi@gmail.com"><i class="fa fa-envelope-o"></i> nirajdharamshi@gmail.com</a></li>
						
					</ul>
					<ul class="header-links pull-right">
						<?php session_start();
						        if(!isset($_SESSION["user"])):?>
						 <li><a href="login.php"><i class="fa fa-user-o"></i> My Account</a></li>
                         <?php 
						        else:?>
						 <li><a><i class="fa fa-user-o"></i> <?php
						 echo 'Hi,' . $_SESSION["user"];
                              ?></a></li>  
                              <li><a href="logout.php"><i class="fa fa-user-o"></i> LogOut</a></li>
                              <?php endif; ?>   
						<li><a href="user.php"><i class="fa fa-user-o"></i> New Users</a></li>
                          
					</ul>
				</div>
			</div>
			<!-- /TOP HEADER -->

			<!-- MAIN HEADER -->
			<div id="header">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<!-- LOGO -->
						<div class="col-md-3">
							<div class="header-logo">
								<a href="index.php" class="logo">
									<img src=".\img\logo.png" alt="">
								</a>
							</div>
						</div>
						<!-- /LOGO -->


						<!-- SEARCH BAR -->

						<script>
    $(document).ready(function(){
    $('input.typeahead').typeahead({
        name: 'typeahead',
        remote:'search.php?key=%QUERY',
        limit : 10
    });
});
    </script>
						<div class="col-md-6">
							<div class="header-search">
								<form method="get" action="search.php">
									<select class="input-select">
										<option value="0">All Store</option>
										
									</select>
									<input class="input" name="key" placeholder="Search here">
									<button class="search-btn" type="submit" name="typehead">Search</button>
								</form>
								  <!-- Suggestions will be displayed in below div. -->

                                <div id="display"></div>
							</div>

						</div>
						<!-- /SEARCH BAR -->

						<!-- ACCOUNT -->
						<div class="col-md-3 clearfix">
							<div class="header-ctn">
								<!-- Wishlist -->
								<div>
									<a href="track.php">
										<i class="fa fa-heart-o"></i>
										<span>Visited Products</span>
										
									</a>
								</div>
								<!-- /Wishlist -->

								<!-- Cart -->
								

								<!-- Menu Toogle -->
								<div class="menu-toggle">
									<a href="#">
										<i class="fa fa-bars"></i>
										<span>Menu</span>
									</a>
								</div>
								<!-- /Menu Toogle -->
							</div>
						</div>
						<!-- /ACCOUNT -->
					</div>
					<!-- row -->
				</div>
				<!-- container -->
			</div>
			<!-- /MAIN HEADER -->
		</header>
		<!-- /HEADER -->

		<!-- NAVIGATION -->
		<nav id="navigation">
			<!-- container -->
			<div class="container">
				<!-- responsive-nav -->
				<div id="responsive-nav">
					<!-- NAV -->
					<ul class="main-nav nav navbar-nav">
						<li class="active"><a href="#">Home</a></li>
						
						<li><a href="dstore.php">Cakes</a></li>
						<li><a href="kstore.php">Ice Cream</a></li>
						<li><a href="store.php">Software</a></li>
						<li><a href="ystore.php">Tutorials</a></li>
						
					</ul>
					<!-- /NAV -->
				</div>
				<!-- /responsive-nav -->
			</div>
			<!-- /container -->
		</nav>
		<!-- /NAVIGATION -->

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<!-- shop -->
					<div class="col-md-3 col-xs-6">
						<div class="shop">
							<div class="shop-img">
								<img src="./img/cakefront.png" alt="">
							</div>
							<div class="shop-body">
								<h3>Cakes<br>Variety</h3>
								<a href="dstore.php" class="cta-btn">Shop now <i class="fa fa-arrow-circle-right"></i></a>
							</div>
						</div>
					</div>
					<!-- /shop -->

					<!-- shop -->
					<div class="col-md-3 col-xs-6">
						<div class="shop">
							<div class="shop-img">
								<img src="./img/icecreamfront.png" />
							</div>
							<div class="shop-body">
								<h3>Ice Cream<br>Flavour</h3>
								<a href="kstore.php" class="cta-btn">Shop now <i class="fa fa-arrow-circle-right"></i></a>
							</div>
						</div>
					</div>
					<!-- /shop -->

					<!-- shop -->
					<div class="col-md-3 col-xs-6">
						<div class="shop">
							<div class="shop-img">
								<img src="./img/softwarefront.png" alt="">
							</div>
							<div class="shop-body">
								<h3>Software<br>Services</h3>
								<a href="store.php" class="cta-btn">Shop now <i class="fa fa-arrow-circle-right"></i></a>
							</div>
						</div>
					</div>
					<!-- /shop -->
						<!-- shop -->
					<div class="col-md-3 col-xs-6">
						<div class="shop">
							<div class="shop-img">
								<img src="./img/tutorialfront.png" alt="">
							</div>
							<div class="shop-body">
								<h3>Tutorials<br>collection</h3>
								<a href="ystore.php" class="cta-btn">Shop now <i class="fa fa-arrow-circle-right"></i></a>
							</div>
						</div>
					</div>
					<!-- /shop -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- HOT DEAL SECTION -->
		<div id="hot-deal" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
						<div class="hot-deal">
							<ul class="hot-deal-countdown">
								<li>
									<div>
										<h3>02</h3>
										<span>Days</span>
									</div>
								</li>
								<li>
									<div>
										<h3>10</h3>
										<span>Hours</span>
									</div>
								</li>
								<li>
									<div>
										<h3>34</h3>
										<span>Mins</span>
									</div>
								</li>
								<li>
									<div>
										<h3>60</h3>
										<span>Secs</span>
									</div>
								</li>
							</ul>
							<h2 class="text-uppercase"><font color="white">hot deal this week</font></h2>
							<p><font color="white">New Collection Up to 50% OFF</font></p>
							<a class="primary-btn cta-btn" href="store.php">Shop now</a>
						</div>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /HOT DEAL SECTION -->

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">

					<!-- section title -->
					<div class="col-md-12">
						<div class="section-title">
							<h3 class="title">Top Picks</h3>
							<div class="section-nav">
							
							</div>
						</div>
					</div>
					<!-- /section title -->

					<!-- Products tab & slick -->
					<div class="col-md-12">
						<div class="row">
							<div class="products-tabs">
								<!-- tab -->
								<div id="tab2" class="tab-pane fade in active">
									<div class="products-slick" data-nav="#slick-nav-2">
								
									

<?php $t = $conn->query("SELECT *  FROM search where count=1",MYSQLI_USE_RESULT) ;

              
?>

<?php
							 while ($o = $t->fetch_assoc()) {?>
									

										<!-- product -->
										<div class="product">
											<div class="product-img">
												<img src="<?php echo ($o['link']); ?>" alt="" width="600" height="150">
												<div class="product-label">
													<span class="sale">-30%</span>
												</div>
											</div>
											<div class="product-body">
												<p class="product-category">Category</p>
												<h3 class="product-name"><a href="<?php echo 'product.php?id='.($o['id']); ?>"><?php echo ($o['name']); ?></a></h3>
												<h4 class="product-price"><?php echo ($o['price']); ?><del class="product-old-price"><?php echo "  ";
										echo ((1.2)*($o['price'])); ?></del></h4>
												<div class="product-rating">
												</div>
												<div class="product-btns">
													
												</div>
											</div>
											
										</div>
										<!-- /product -->
										 <?php  } ?>

											
									</div>
									<div id="slick-nav-2" class="products-slick-nav"></div>
								</div>
								<!-- /tab -->
							</div>
						</div>
					</div>
					<!-- /Products tab & slick -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-3 col-xs-6">
						<div class="section-title">
							<h4 class="title">Kailash's Top Seling</h4>
							<div class="section-nav">
								<div id="slick-nav-3" class="products-slick-nav"></div>
							</div>
						</div>
						<div class="products-widget-slick" data-nav="#slick-nav-3">
                       <?php $res = $conn->query("SELECT *  FROM kailash where fav=1",MYSQLI_USE_RESULT);

              
?>
						
							<div><?php
							 while ($r = $res->fetch_assoc()) {?>
								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="<?php echo ($r['link']); ?>" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="<?php echo 'product.php?id='.($r['id']); ?>"><?php echo ($r['name']); ?></a></h3>
										<h4 class="product-price"><?php echo ($r['price']); ?><del class="product-old-price"><?php echo "  ";
										echo ((1.2)*($r['price'])); ?></del></h4>
									</div>
								</div>


								<!-- /product widget -->
								 <?php  } ?>

							</div>

						</div>
					</div>

					<div class="col-md-3 col-xs-6">
						<div class="section-title">
							<h4 class="title">Niraj's Top selling</h4>
							<div class="section-nav">
								<div id="slick-nav-4" class="products-slick-nav"></div>
							</div>
						</div>
<?php $resn = $conn->query("SELECT *  FROM niraj where fav=1",MYSQLI_USE_RESULT);

              
?>
						<div class="products-widget-slick" data-nav="#slick-nav-4">
							<div>
								<?php
							 while ($ro = $resn->fetch_assoc()) {?>
								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="<?php echo ($ro['link']); ?>" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="<?php echo 'product.php?id='.($ro['id']); ?>"><?php echo ($ro['name']); ?></a></h3>
										<h4 class="product-price"><?php echo ($ro['price']); ?><del class="product-old-price"><?php echo "  ";
										echo ((1.2)*($ro['price'])); ?></del></h4>
									</div>
								</div>
								<!-- /product widget -->
								 <?php  } ?>


								
							</div>

							
						</div>
					</div>

					<div class="clearfix visible-sm visible-xs"></div>

					<div class="col-md-3 col-xs-6">
						<div class="section-title">
							<h4 class="title">Yudhajith's Top selling</h4>
							<div class="section-nav">
								<div id="slick-nav-5" class="products-slick-nav"></div>
							</div>
						</div>
                         <?php $resu = $conn->query("SELECT *  FROM yudhajith where fav=1",MYSQLI_USE_RESULT);

              
?>
						<div class="products-widget-slick" data-nav="#slick-nav-5">
							<div>

									<?php
							 while ($ra = $resu->fetch_assoc()) {?>
								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="<?php echo ($ra['link']); ?>" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="<?php echo 'product.php?id='.($ra['id']); ?>"><?php echo ($ra['name']); ?></a></h3>
										<h4 class="product-price"><?php echo ($ra['price']); ?><del class="product-old-price"><?php echo "  ";
										echo ((1.2)*($ra['price'])); ?></del></h4>
									</div>
								</div>
								 <?php  } ?>
								<!-- /product widget -->

							</div>
</div>
</div>
							<div class="clearfix visible-sm visible-xs"></div>
                       <?php $resul = $conn->query("SELECT *  FROM d where fav=1",MYSQLI_USE_RESULT);

              
?>
					<div class="col-md-3 col-xs-6">
						<div class="section-title">
							<h4 class="title">Dhruthi's Top selling</h4>
							<div class="section-nav">
								<div id="slick-nav-5" class="products-slick-nav"></div>
							</div>
						</div>

						<div class="products-widget-slick" data-nav="#slick-nav-5">
							<div>
								<!-- product widget -->
								<?php
							 while ($d = $resul->fetch_assoc()) {?>
								<div class="product-widget">
									<div class="product-img">
										<img src="<?php echo ($d['link']); ?>" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="<?php echo 'product.php?id='.($d['id']); ?>"><?php echo ($d['name']); ?></a></h3>
										<h4 class="product-price"><?php echo ($d['price']); ?><del class="product-old-price"><?php echo "  ";
										echo ((1.2)*($d['price'])); ?></del></h4>
									</div>
								</div>
								 <?php  } ?>
								<!-- /product widget -->

								

							
							</div>

						</div>
					</div>

				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- NEWSLETTER -->
		<div id="newsletter" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
						<div class="newsletter">
							<p>Sign Up for the <strong>NEWSLETTER</strong></p>
							<form action="email.php" method="post">
								<input class="input" type="email"  name="email" placeholder="Enter Your Email">
								<button class="newsletter-btn"><i class="fa fa-envelope"></i> Subscribe</button>
							</form>
							<ul class="newsletter-follow">
								<li>
									<a href="https://www.facebook.com/shopmart.shopmart.524"><i class="fa fa-facebook"></i></a>
								</li>
								<li>
									<a href="https://twitter.com/shopmart90"><i class="fa fa-twitter"></i></a>
								</li>
								<li>
									<a href="https://www.instagram.com/ourshopmart/"><i class="fa fa-instagram"></i></a>
								</li>
								
							</ul>
							<!-- <iframe width="560" height="315" src="https://www.youtube.com/embed/JrB4dU48VTM" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe> -->
						</div>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /NEWSLETTER -->

		<!-- FOOTER -->
		<footer id="footer">
			<!-- top footer -->
			<div class="section">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">About Us</h3>
								<p>Hey this is where you do crazy shopping!</p>
								<ul class="footer-links">
									<li><i class="fa fa-map-marker"></i>33rd South 3rd Street</li>
									<li><a href="#"><i class="fa fa-phone"></i>+021-95-51-84</a></li>
									<li><a href="#"><i class="fa fa-envelope-o"></i>yudhajith@gmail.com</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Categories</h3>
								<ul class="footer-links">
									
									<li><a href="dstore.php">Cakes</a></li>
									<li><a href="kstore.php">Ice Cream</a></li>
									<li><a href="store.php">Software Services</a></li>
									<li><a href="ystore.php">Tutorials</a></li>
								</ul>
							</div>
						</div>

						<div class="clearfix visible-xs"></div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Information</h3>
								<ul class="footer-links">
									<li>About Us</li>
									<li><a href="http://elliex.ellipsis.tech">Niraj's Web</a></li>
									<li><a href="http://www.yudhajithb.com">Yudhajith's Web</a></li>
									<li><a href="http://www.kailashr.com">Kailash's Web</a></li>
									<li><a href="http://www.dhruthikuram.com">Dhruthi's Web</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Service</h3>
								<ul class="footer-links">
									<li><a href="login.php">Login</a></li>
									<li><a href="track.php">Last Visted</a></li>
									
									
								</ul>
							</div>
						</div>
					</div>
					<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /top footer -->

			<!-- bottom footer -->
			<div id="bottom-footer" class="section">
				<div class="container">
					<!-- row -->
					<div class="row">
						<div class="col-md-12 text-center">
						
							<span class="copyright">
								<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
								Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This website is made with <i class="fa fa-heart-o" aria-hidden="true"></i>
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
							</span>
						</div>
					</div>
						<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /bottom footer -->
		</footer>
		<!-- /FOOTER -->

			<!-- ajax -->
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
		<script type="text/javascript" src="script.js"></script>


		<!-- jQuery Plugins -->
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/slick.min.js"></script>
		<script src="js/nouislider.min.js"></script>
		<script src="js/jquery.zoom.min.js"></script>
		<script src="js/main.js"></script>

	</body>
</html>
