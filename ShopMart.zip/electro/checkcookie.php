<? php

if(isset($_COOKIE['cookie'])){
  echo  $cookie = $_COOKIE['cookie'];
}
else{
    // Cookie is not set
}

?>