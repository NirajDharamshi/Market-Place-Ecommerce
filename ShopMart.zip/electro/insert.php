<?php
include 'db.php'; 


$firstname=mysqli_real_escape_string($conn, $_REQUEST['firstname']);
$lastname=mysqli_real_escape_string($conn, $_REQUEST['lastname']);
$email=mysqli_real_escape_string($conn, $_REQUEST['email']);
$password1=mysqli_real_escape_string($conn, $_REQUEST['password']);
$homeaddress=mysqli_real_escape_string($conn, $_REQUEST['homeaddress']);
$number=mysqli_real_escape_string($conn, $_REQUEST['number']);
$cellnumber=mysqli_real_escape_string($conn, $_REQUEST['cellnumber']);

$sql = "INSERT INTO user (first_name, last_name, email,password,address,home,cell) VALUES ('$firstname','$lastname','$email','$password1','$homeaddress','$number','$cellnumber')";

if ($conn->query($sql) === TRUE) {
	echo"<script type='text/javascript'>alert('User Created!');</script>";
	echo "<script>location.href='index.html';</script>";

    	

} else {


   
   	echo"<script type='text/javascript'>alert('User Exists or Your luck?');</script>";
   	echo "<script>location.href='user.php';</script>";
}

$conn->close();
?>