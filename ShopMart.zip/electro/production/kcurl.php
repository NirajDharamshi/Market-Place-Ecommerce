<?php

 
$ch = curl_init();

/**
* Set the URL of the page or file to download.
*/
curl_setopt($ch, CURLOPT_URL, "http://kailashr.com/integration.php");

/**
* Create a new file
*/
$fp = fopen("k.txt", "w");

/**
* Ask cURL to write the contents to a file
*/
curl_setopt($ch, CURLOPT_FILE, $fp);

/**
* Execute the cURL session
*/
curl_exec ($ch);

/**
* Close cURL session and file
*/
curl_close ($ch);
fclose($fp);
    // end loop here

$handle = fopen("k.txt", "r"); //read line one by one
$values='';

include 'db.php';


while (!feof($handle)) // Loop til end of file.
{
    $buffer = fgets($handle, 4096); // Read a line.
    if($buffer!="")
   {
    $col=explode("|",$buffer);//Separate string by the means of |
    //values.=($a,$b,$c);// save values and use insert query at last or
     echo $col[0].",".$col[1].",".$col[2].",".$col[3];
     echo "<br>";

     $sql = "INSERT INTO kailash (name, description, price,link) VALUES ('$col[0]','$col[1]','$col[2]','$col[3]')";
   
 if ($conn->query($sql) === TRUE) {
	//echo"<script type='text/javascript'>alert('User Created!');</script>";
    	

} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
    }// use mysql insert query here
    
}

echo '<script type="text/javascript">
           window.location = "kcurlview.php"
      </script>';






?>