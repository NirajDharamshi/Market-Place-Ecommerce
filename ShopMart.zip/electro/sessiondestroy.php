<?php
   session_destroy();
?>