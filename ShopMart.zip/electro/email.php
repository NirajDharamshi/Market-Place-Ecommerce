<?php

if(isset($_POST['email'])){

    $to = $_POST['email'];

    $from = "nirajdharamshi@gmail.com"; 

     

    $first_name = 'Niraj';


    $subject = "Thankyou for newsletter Subscription";

    $message = "Thanks for subscribing our newsletter";

    



    $headers = "From: ". $from;

    

    $emailresult = @mail($to,$subject,$message,$headers);

    if($emailresult)

    {

  echo'<h4 align="center">Email Sent. Thank you for placing the order. We will deliver the items to you shortly</h4>';

 

  }

    //header('Location: thank_you.php');

     //echo'Email Sent. Thank you '. $first_name . '. We will deliver the items to you shortly.';

    // You can also use header('Location: thank_you.php'); to redirect to another page.

    }

    ?>